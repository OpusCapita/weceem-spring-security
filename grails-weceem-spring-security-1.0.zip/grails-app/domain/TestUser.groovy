class TestUser {
    String username
}